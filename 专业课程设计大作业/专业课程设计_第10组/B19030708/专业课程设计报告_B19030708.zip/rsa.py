def RSA():
    global flag
    flag=False
    while not flag:

        p = getprime(32)  # 1024bit的大整数
        q = getprime(32)
        while p == q:  # 避免p/q值相同
            q = getprime(1)
        n = p * q  # n值公开
        OrLa = (p - 1) * (q - 1)  # 欧拉函数
        e = 49999#选择一个整数e作为秘钥，需要满足：gcd(e, OrLa)=1 && e<OrLa ，e可以直接用一个大素数

        d = Mod_1(e, OrLa)

        message = 'theKingOfNight'
        # 从标准输入输出流接收数据，数字化再加解密
        message = list(map(ord, message))

        ciphertext = []
        for x in message:
            ciphertext.append(pow(x, e, n))

        message = ciphertext
        plaintext = []
        for x in message:
            plaintext.append(pow(x, d, n))

        if int(plaintext[0]) <= 256:
            flag = True

    return e, n, d