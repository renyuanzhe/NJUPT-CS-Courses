
from tkinter import ttk
from tkinter.scrolledtext import ScrolledText

from tkinter import * #for gui


from aes_file import *
from rsa import *


from aes_file import filepaths,encrypt,decrypt
def gui_AES_Encrypt():#加密文件夹
    package_path = package_path_input.get(1.0, END)
    package_path = package_path.rstrip('\n')  # 移除行尾换行符
    key=AES_Key_input.get(1.0, END)
    key = key.rstrip('\n')  # 移除行尾换行符
    all_files_path(package_path)  # 对文件夹路径下的文件进行读取

    for file_name in filepaths:  # 对文件进行循环加密
        encrypt(file_name, key)#string,string
    print(filepaths)
    return


def gui_AES_Decrypt():#解密文件夹
    package_path = package_path_input2.get(1.0, END)
    package_path = package_path.rstrip('\n')  # 移除行尾换行符
    key=AES_Key_input2.get(1.0, END)
    key = key.rstrip('\n')  # 移除行尾换行符
    all_files_path(package_path)  # 对文件夹路径下的文件进行读取

    for file_name in filepaths:  # 对文件进行循环加密
        decrypt(file_name, key) #string,string
    print(filepaths)
    return


def gui_RSA_Encrypt():
    plain_text=AES_Key_input3.get(1.0, END)
    plain_text = plain_text.rstrip('\n')  # 移除行尾换行符
    e=int(RSA_e_3.get(1.0, END))
    n=int(RSA_n_3.get(1.0, END))

    cipher_text= encrypt_text_rsa(e, n, plain_text)
    RSA_cipher_text3.delete('1.0', END)
    RSA_cipher_text3.insert(1.0, cipher_text)
    return cipher_text

def gui_RSA_Decrypt():
    ciper_text=Ciper_input4.get(1.0, END)
    ciper_text = ciper_text.rstrip('\n')  # 移除行尾换行符
    d=int(RSA_d_4.get(1.0, END))
    n=int(RSA_n_4.get(1.0, END))

    plain_text= decrypt_text_rsa(d, n, ciper_text)
    AES_Key_plaintext4.delete('1.0', END)
    AES_Key_plaintext4.insert(1.0, plain_text)
    return plain_text



def gui_generate_RSA_keys():
    e5, n5, d5 = RSA()
    RSA_e_5.delete('1.0', END)
    RSA_e_5.insert(1.0, e5)

    RSA_n_5.delete('1.0', END)
    RSA_n_5.insert(1.0, n5)

    RSA_d_5.delete('1.0', END)
    RSA_d_5.insert(1.0, d5)
    return


########################################################################
root = Tk()
root.title("U盘加密系统,信安实验大作业")
root.geometry("920x750")
# root.configure(bg='white')
s = ttk.Style(root)
s.configure("TNotebook", tabposition='n',background='#6C6C6C')
s.configure("TFrame",background='#FAEBD7')
notebook = ttk.Notebook(root,padding=20);
notebook.pack(expand=1, fill="both")
frame1 = ttk.Frame(notebook,relief=GROOVE,padding=5)
frame2 = ttk.Frame(notebook,relief=GROOVE,padding=5)
frame3 = ttk.Frame(notebook,relief=GROOVE,padding=5)
frame4 = ttk.Frame(notebook,relief=GROOVE,padding=5)
frame5 = ttk.Frame(notebook,relief=GROOVE,padding=5)


notebook.add(frame1, text='   Encrypt package via AES  ')
notebook.add(frame2, text='   Decrypt package via AES  ')
notebook.add(frame3, text='   Encrypt AES Key via RSA  ')
notebook.add(frame4, text='   Decrypt AES Key via RSA  ')
notebook.add(frame5, text='   RSA parameters  ')

####################################   page1加密文件夹
Label(frame1,text="  Encrypt package via AES: ",font=('Arial', 14, 'bold'),background='#FAEBD7').grid(padx=5,pady=10,row=0,column=0)

Label(frame1,text="Enter the Package Path: ",font=('Arial', 12),background='#FAEBD7').grid(padx=5,pady=10,row=3,column=0)
package_path_input=ScrolledText(frame1,width=80,height=5)#文件夹路径输入框
package_path_input.grid(padx=5,pady=10,row=3, column=1,sticky="E",columnspan=4)

Label(frame1,text="Enter the  AES Key: ",font=('Arial', 12),background='#FAEBD7').grid(padx=5,pady=10,row=4,column=0)
AES_Key_input=ScrolledText(frame1,width=80,height=5)#AES密钥输入框
AES_Key_input.grid(padx=5,pady=10,row=4, column=1,sticky="E",columnspan=4)


AES_Encrypt_Button=Button(frame1,text = " Encrypt package ",font=('Arial', 12),activebackground='Coral',background='LightSeaGreen',relief=FLAT,command=gui_AES_Encrypt)
AES_Encrypt_Button.grid(ipadx=10,ipady=10,padx=5,pady=10,row=5,column=2)



####################################  page2解密文件夹
Label(frame2,text="  Decrypt package via AES: ",font=('Arial', 14, 'bold'),background='#FAEBD7').grid(padx=5,pady=10,row=0,column=0)

Label(frame2,text="Enter the Package Path: ",font=('Arial', 12),background='#FAEBD7').grid(padx=5,pady=10,row=3,column=0)
package_path_input2=ScrolledText(frame2,width=80,height=5)#文件夹路径输入框
package_path_input2.grid(padx=5,pady=10,row=3, column=1,sticky="E",columnspan=4)

Label(frame2,text="Enter the  AES Key: ",font=('Arial', 12),background='#FAEBD7').grid(padx=5,pady=10,row=4,column=0)
AES_Key_input2=ScrolledText(frame2,width=80,height=5)#AES密钥输入框
AES_Key_input2.grid(padx=5,pady=10,row=4, column=1,sticky="E",columnspan=4)


AES_Decrypt_Button=Button(frame2,text = " Decrypt package ",font=('Arial', 12),activebackground='Coral',background='LightSeaGreen',relief=FLAT,command=gui_AES_Decrypt)
AES_Decrypt_Button.grid(ipadx=10,ipady=10,padx=5,pady=10,row=5,column=2)


####################################     page3用公钥加密AES密钥
Label(frame3,text="  Encrypt AES Key via RSA: ",font=('Arial', 14, 'bold'),background='#FAEBD7').grid(padx=5,pady=10,row=3,column=0)

Label(frame3,text=" Enter AES Key (Plaintext): ",font=('Arial', 12),background='#FAEBD7').grid(padx=5,pady=10,row=4,column=0)
AES_Key_input3=ScrolledText(frame3,width=80,height=5)
AES_Key_input3.grid(padx=5,pady=10,row=4, column=1,sticky="E",columnspan=4)

Label(frame3,text=" Enter RSA Public Key e: ",font=('Arial', 12),background='#FAEBD7').grid(padx=5,pady=10,row=5,column=0)
RSA_e_3=ScrolledText(frame3,width=80,height=5)
RSA_e_3.grid(padx=5,pady=10,row=5, column=1,sticky="E",columnspan=2)

Label(frame3,text=" Enter RSA Public Key n ",font=('Arial', 12),background='#FAEBD7').grid(padx=5,pady=10,row=6,column=0)
RSA_n_3=ScrolledText(frame3,width=80,height=5)
RSA_n_3.grid(padx=5,pady=5,row=6, column=1,sticky="E",columnspan=4)



RSA_Encrypt_Button=Button(frame3,text = " Encrypt ",activebackground='Coral',font=('Arial', 12),background='LightSeaGreen',relief=FLAT,command=gui_RSA_Encrypt)
RSA_Encrypt_Button.grid(ipadx=10,ipady=10,padx=5,pady=10,row=27,column=1)

Label(frame3,text=" Ciper Text: ",font=('Arial', 12),background='#FAEBD7').grid(padx=5,pady=10,row=28,column=0)
RSA_cipher_text3=ScrolledText(frame3,width=80,height=5)
RSA_cipher_text3.grid(padx=5,pady=5,row=28, column=1,sticky="E",columnspan=4)


####################################     page4用私钥解密AES密钥
Label(frame4,text="  Decrypt AES Key via RSA: ",font=('Arial', 14, 'bold'),background='#FAEBD7').grid(padx=5,pady=10,row=3,column=0)

Label(frame4,text=" Enter Ciper Text: ",font=('Arial', 12),background='#FAEBD7').grid(padx=5,pady=10,row=4,column=0)
Ciper_input4=ScrolledText(frame4,width=80,height=5)
Ciper_input4.grid(padx=5,pady=10,row=4, column=1,sticky="E",columnspan=4)

Label(frame4,text=" Enter RSA Private Key d: ",font=('Arial', 12),background='#FAEBD7').grid(padx=5,pady=10,row=5,column=0)
RSA_d_4=ScrolledText(frame4,width=80,height=5)
RSA_d_4.grid(padx=5,pady=10,row=5, column=1,sticky="E",columnspan=2)

Label(frame4,text=" Enter RSA Public Key n ",font=('Arial', 12),background='#FAEBD7').grid(padx=5,pady=10,row=6,column=0)
RSA_n_4=ScrolledText(frame4,width=80,height=5)
RSA_n_4.grid(padx=5,pady=5,row=6, column=1,sticky="E",columnspan=4)

RSA_Decrypt_Button=Button(frame4,text = " Decrypt ",activebackground='Coral',font=('Arial', 12),background='LightSeaGreen',relief=FLAT,command=gui_RSA_Decrypt)
RSA_Decrypt_Button.grid(ipadx=10,ipady=10,padx=5,pady=10,row=27,column=1)

Label(frame4,text=" AES Key (Plaintext): ",font=('Arial', 12),background='#FAEBD7').grid(padx=5,pady=10,row=28,column=0)
AES_Key_plaintext4=ScrolledText(frame4,width=80,height=5)
AES_Key_plaintext4.grid(padx=5,pady=5,row=28, column=1,sticky="E",columnspan=4)


####################################   page5 生成RSA公私钥
Label(frame5,text="  Generate RSA Parameters: ",font=('Arial', 14, 'bold'),background='#FAEBD7').grid(padx=5,pady=10,row=0,column=0)


Generate_RSA_Keys_Button=Button(frame5,text = " Generate RSA Keys ",font=('Arial', 12),activebackground='Coral',background='LightSeaGreen',relief=FLAT,command=gui_generate_RSA_keys)
Generate_RSA_Keys_Button.grid(ipadx=10,ipady=10,padx=5,pady=10,row=4,column=2)

Label(frame5,text="Public Key_e: ",font=('Arial', 12),background='#FAEBD7').grid(padx=5,pady=10,row=5,column=0)
RSA_e_5=ScrolledText(frame5,width=80,height=5)
RSA_e_5.grid(padx=5,pady=10,row=5, column=1,sticky="E",columnspan=4)

Label(frame5,text="Public Key_n: ",font=('Arial', 12),background='#FAEBD7').grid(padx=5,pady=10,row=6,column=0)
RSA_n_5=ScrolledText(frame5,width=80,height=5)
RSA_n_5.grid(padx=5,pady=10,row=6, column=1,sticky="E",columnspan=4)

Label(frame5,text="Private Key_d: ",font=('Arial', 12),background='#FAEBD7').grid(padx=5,pady=10,row=7,column=0)
RSA_d_5=ScrolledText(frame5,width=80,height=5)
RSA_d_5.grid(padx=5,pady=10,row=7, column=1,sticky="E",columnspan=4)



####################################
root.mainloop()
####################################


